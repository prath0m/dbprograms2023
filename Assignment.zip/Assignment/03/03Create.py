# Create a table "MOBILES" with prodid as primary key and other fields like modelname, company, connectivity(4G/5G), ram, rom,color, screen, battery, processor, price, rating (4.3 out of 5)

import pymysql

conn = pymysql.connect(host='b35fhkxul9dakrrvpl8v-mysql.services.clever-cloud.com',user='ujdoqeqcusxjjas5',password='W5zppJbaAzak5mXKEMTO',database='b35fhkxul9dakrrvpl8v')

cursor = conn.cursor()
try: 
    cursor.execute('CREATE TABLE mobiles (prodid INTEGER PRIMARY KEY, modelname VARCHAR(30), company VARCHAR(30), connectivity VARCHAR(5), ram INTEGER,rom INTEGER,color VARCHAR(30), screen VARCHAR(30),battery INTEGER, processor VARCHAR(30), price DECIMAL(10, 2), rating DECIMAL(2, 1))')
    print('Table Created Successfully')
except:
    print('Table of Given Name is Already Exits')

conn.commit()
conn.close()