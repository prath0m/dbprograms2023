# Create a parameterized stored procedure to reduce the price of a company's products by a specified amount. Call the SP from aprogram.


'''
Procedure

CREATE PROCEDURE ReducePrice (
    IN comp VARCHAR(30),
    IN amount DECIMAL(10, 2)
)
BEGIN
    UPDATE MOBILES SET price = price - amount WHERE company = comp
END;

'''

import pymysql

conn = pymysql.connect(host='b35fhkxul9dakrrvpl8v-mysql.services.clever-cloud.com',user='ujdoqeqcusxjjas5',password='W5zppJbaAzak5mXKEMTO',database='b35fhkxul9dakrrvpl8v')
cursor = conn.cursor()
try:
    company = input("Enter the company name: ")
    amount = float(input("Enter the amount to reduce the price by: "))

    cursor.callproc('ReducePrice', (company, amount))

    conn.commit()
    print("Price reduced successfully.")
    
except:
    print(Exception)

conn.close()