# Write a program to accept modelname, search mobile in the tables show the mobile details if found else display "not found" message

import pymysql

conn = pymysql.connect(host='b35fhkxul9dakrrvpl8v-mysql.services.clever-cloud.com',user='ujdoqeqcusxjjas5',password='W5zppJbaAzak5mXKEMTO',database='b35fhkxul9dakrrvpl8v')

cursor = conn.cursor()

mn = input("Enter the model name: ")

try:
    cursor.execute("SELECT * FROM mobiles WHERE modelname = %s", mn)
    
    data = cursor.fetchone()
    
    if data:
        print(" ")
        print('Product ID: ',data[0])
        print('Model Name: ',data[1])
        print('Company: ',data[2])
        print('Connectivity: ',data[3],'G')
        print('Ram: ',data[4],'GB')
        print('Rom: ',data[5],'GB')
        print('Color: ',data[6])
        print('Screen: ',data[7])
        print('Battery: ',data[8],'mAh')
        print('Processor: ',data[9])
        print('Price: Rs ',data[10])
        print('Rating: ',data[11])
        
    else:

        print("Mobile not found.")
    
except:
    print(Exception)


conn.close()
