# Write a program to accept ram and rom, display list of mobiles of the ram-rom storage space combination
import pymysql

conn = pymysql.connect(host='b35fhkxul9dakrrvpl8v-mysql.services.clever-cloud.com',user='ujdoqeqcusxjjas5',password='W5zppJbaAzak5mXKEMTO',database='b35fhkxul9dakrrvpl8v')

cursor = conn.cursor()

ram = int(input("Enter the RAM: "))
rom = int(input("Enter the ROM: "))

try:
    cursor.execute("SELECT * FROM mobiles WHERE ram = %s AND rom = %s", (ram, rom))
    data = cursor.fetchall()
    
    if data:
        
        print('List of Mobiles with %d GB RAM and %d GB ROM: '%(ram,rom))
        print(data)
    
    else:
        print('No mobiles found with %d GB RAM and %d GB ROM.'%(ram,rom))
    
except:
    print(Exception)

conn.close()
