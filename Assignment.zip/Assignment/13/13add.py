# Write a program to accept modelname and purpose, update all mobiles of the model with the purpose ( gaming/office/social, etc.)

import pymysql

conn = pymysql.connect(host='b35fhkxul9dakrrvpl8v-mysql.services.clever-cloud.com',user='ujdoqeqcusxjjas5',password='W5zppJbaAzak5mXKEMTO',database='b35fhkxul9dakrrvpl8v')

cursor = conn.cursor()
modelname = input("Enter the model name: ")
purpose = input("Enter the purpose: ")

try:
    cursor.execute("UPDATE mobiles SET purpose = %s WHERE modelname = %s",(purpose, modelname))
    conn.commit()

    if cursor.rowcount > 0:
        print("Mobiles of %s updated with purpose '%s' successfully." %(modelname, purpose))
    else:
        print("No mobiles found with the specified modelname.")
    
except:
    print(Exception)

conn.close()
