# Write a program to show list of all mobiles

import pymysql

conn = pymysql.connect(host='b35fhkxul9dakrrvpl8v-mysql.services.clever-cloud.com',user='ujdoqeqcusxjjas5',password='W5zppJbaAzak5mXKEMTO',database='b35fhkxul9dakrrvpl8v')

cursor = conn.cursor()
cursor.execute("SELECT * FROM mobiles")
data = cursor.fetchall()
print(data)

conn.close()