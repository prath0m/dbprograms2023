# Write a program to accept company like "samsung" and display list of mobiles of that category in the ascending order of price

import pymysql

conn = pymysql.connect( host='b35fhkxul9dakrrvpl8v-mysql.services.clever-cloud.com',user='ujdoqeqcusxjjas5',password='W5zppJbaAzak5mXKEMTO',database='b35fhkxul9dakrrvpl8v')

cursor = conn.cursor()

company = input("Enter the company name: ")

try:

    cursor.execute("SELECT * FROM mobiles WHERE company = %s ORDER BY price ASC", company)
    
    data = cursor.fetchall()
    
    if data:
        
        print("List of Mobiles from %s in ascending order of price: "%company)
        print('\n',data)
    else:    
        print("No mobiles found for %s"%company)
    
except:
    print(Exception)

conn.close()
