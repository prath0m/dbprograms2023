# Write a program to accept prodid, display the mobile data and ask "Do you want to delete?" if "yes" delete the mobile from the table

import pymysql

conn = pymysql.connect(host='b35fhkxul9dakrrvpl8v-mysql.services.clever-cloud.com',user='ujdoqeqcusxjjas5', password='W5zppJbaAzak5mXKEMTO',database='b35fhkxul9dakrrvpl8v')

cursor = conn.cursor()

prodid = int(input("Enter the prodid: "))

try:
    cursor.execute("SELECT * FROM mobiles WHERE prodid = %s", prodid)
    data = cursor.fetchone()
    
    if data:
        print(data)        

        confirm = input("Do you want to delete this mobile? (yes/no): ")

        if confirm.lower() == "yes":
            
            cursor.execute("DELETE FROM mobiles WHERE prodid = %s", prodid)
            conn.commit()

            print("Mobile deleted successfully.")
        else:
            print("Deletion canceled.")
    else:
        print("Mobile does not exist.")
    
except :
    print(Exception)

conn.close()
