# Write a program to take new mobile data as input and add mobile to the DB table

import pymysql

conn = pymysql.connect(host='b35fhkxul9dakrrvpl8v-mysql.services.clever-cloud.com',user='ujdoqeqcusxjjas5',password='W5zppJbaAzak5mXKEMTO',database='b35fhkxul9dakrrvpl8v')

cursor = conn.cursor()

prodid = int(input("Enter the prodid: "))
modelname = input("Enter the model name: ")
company = input("Enter the company: ")
connectivity = input("Enter the connectivity (4G/5G): ")
ram = int(input("Enter the RAM: "))
rom = int(input("Enter the ROM: "))
color = input("Enter the color: ")
screen = input("Enter the screen: ")
battery = int(input("Enter the battery: "))
processor = input("Enter the processor: ")
price = float(input("Enter the price: "))
rating = float(input("Enter the rating: "))

try:
    cursor.execute("INSERT INTO mobiles VALUES (%d, '%s', '%s', '%s', %d, %d, '%s', '%s', %d, '%s', %f, %f)" %(prodid, modelname, company, connectivity, ram, rom, color, screen, battery, processor, price, rating))
    print('Mobile added successfully')
except:
    print('Product Already Exist')

conn.commit()
conn.close()