# Add new column "purpose varchar(50)" to the mobiles table using alter query

import pymysql

conn = pymysql.connect(host='b35fhkxul9dakrrvpl8v-mysql.services.clever-cloud.com',user='ujdoqeqcusxjjas5',password='W5zppJbaAzak5mXKEMTO',database='b35fhkxul9dakrrvpl8v')

cursor = conn.cursor()

try:
    cursor.execute("ALTER TABLE mobiles ADD COLUMN purpose VARCHAR(30)")
    print("New column 'purpose' added successfully.")
    
    conn.commit()
    
except:
    print(Exception)

conn.close()
