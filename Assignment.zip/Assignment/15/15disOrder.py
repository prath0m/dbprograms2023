# Take field as an input like rom and display all mobiles in the descending order of the that field.

import pymysql

conn = pymysql.connect(host='b35fhkxul9dakrrvpl8v-mysql.services.clever-cloud.com',user='ujdoqeqcusxjjas5',password='W5zppJbaAzak5mXKEMTO',database='b35fhkxul9dakrrvpl8v')
cursor = conn.cursor()

try:
    field = input("Enter the field to sort by: ")
    cursor.execute("SELECT * FROM mobiles ORDER BY %s DESC",(field))
    data = cursor.fetchall()
    print(data)
    
except :
    print(Exception)

conn.close()
