# Write a program to display group by information - brand, total models under the company, average price and average rating

import pymysql
conn = pymysql.connect(host='b35fhkxul9dakrrvpl8v-mysql.services.clever-cloud.com',user='ujdoqeqcusxjjas5',password='W5zppJbaAzak5mXKEMTO',database='b35fhkxul9dakrrvpl8v')
cursor = conn.cursor()
try:
    cursor.execute("SELECT company AS brand, COUNT(modelname) AS total_models, AVG(price) AS avg_price, AVG(rating) AS avg_rating FROM mobiles GROUP BY company")
    data = cursor.fetchall()

    for d in data:
        print(" ")
        print("brand: ",d[0])
        print("total models: ",d[1])
        print("Average Price: ",d[2])
        print("Average rating: ",d[3])     
except :
    print(Exception)

conn.close()