# Write a program to accept prodid & new price and update price is the mobile data in the table if found else display "mobile does not exist

import pymysql

conn = pymysql.connect(host='b35fhkxul9dakrrvpl8v-mysql.services.clever-cloud.com',user='ujdoqeqcusxjjas5',password='W5zppJbaAzak5mXKEMTO',database='b35fhkxul9dakrrvpl8v')

cursor = conn.cursor()

prodid = int(input("Enter the product id: "))
new_price = float(input("Enter the new price: "))

try:
    cursor.execute("UPDATE mobiles SET price = %f WHERE prodid = %d" %(new_price, prodid))
    
    if cursor.rowcount > 0:
        conn.commit()
        print("Price updated successfully.")
    else:
        print("Mobile does not exist.")
    
except:
    print(Exception)

conn.close()
